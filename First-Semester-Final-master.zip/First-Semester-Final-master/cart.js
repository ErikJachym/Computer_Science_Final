class Cart{
  //What is the first part of every class? Type it below.



  //Type the instance functions below this comment.


}
