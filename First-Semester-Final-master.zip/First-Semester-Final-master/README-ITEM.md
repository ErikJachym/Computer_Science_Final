#The Item Class

This class is a blueprint for the **item-object**. This object has no instance functions but it does have three instance variables.
  -  **name** //as in the name of the item.
  -  **price** //as in how much it costs.
  -  **shipping** //as in how many days it will take to send.

Below your class blueprint, I would like you to create three item objects. Think about potential Christmas gifts for inspiration.
