class Password{
  //The first part of the class.



  //Instance functions below this comment.



  //Static function below this comment.
}
