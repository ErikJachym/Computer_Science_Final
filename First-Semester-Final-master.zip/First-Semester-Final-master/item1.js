class Item{
  //Fill in the item class below this comment.
constructor(n,p,s){
this.name= n;
this.price= p;
this.shipping = s;
}


}

//Create your three test items below this comment.
var computer = new Item("Alienware",1500,15.99);
var shoes = new Item("Nike",90,13.99);
var system = new Item("Gamecube",80,20.99);
